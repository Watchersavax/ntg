import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { UserComponent } from "./user.component";
import { Routes } from "@angular/router";
import { AppRoutingModule } from "../app-routing.module";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";

@NgModule({
  declarations: [UserComponent],
  imports: [CommonModule, BrowserAnimationsModule]
})
export class UserModule {}
