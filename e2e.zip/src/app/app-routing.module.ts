import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { UserComponent } from "./user/user.component";
import { AdminComponent } from "./admin/admin.component";
import { BusinessComponent } from "./business/business.component";
import { CourtComponent } from "./court/court.component";

const routes: Routes = [
  {
    path: "",
    redirectTo: "/user",
    pathMatch: "full"
  },
  {
    path: "user",
    component: UserComponent
  },
  {
    path: "admin",
    component: AdminComponent
  },
  {
    path: "business",
    component: BusinessComponent
  },
  {
    path: "court",
    component: CourtComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
