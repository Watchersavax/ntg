import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { CourtComponent } from "./court.component";
import { AppRoutingModule } from "../app-routing.module";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";

@NgModule({
  declarations: [CourtComponent],
  imports: [CommonModule, BrowserAnimationsModule]
})
export class CourtModule {}
