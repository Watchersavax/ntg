import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { BusinessComponent } from "./business.component";
import { AppRoutingModule } from "../app-routing.module";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";

@NgModule({
  declarations: [BusinessComponent],
  imports: [CommonModule]
})
export class BusinessModule {}
