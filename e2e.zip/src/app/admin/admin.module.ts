import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { AdminComponent } from "./admin.component";
import { MaterialModule } from "../material-module";

import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { AdminRoutingModule } from "./admin-routing-module";

@NgModule({
  declarations: [AdminComponent],
  imports: [
    CommonModule,
    MaterialModule,
    BrowserAnimationsModule,
    AdminRoutingModule
  ],
  exports: [AdminComponent]
})
export class AdminModule {}
